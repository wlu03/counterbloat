"""Synthetic unit tests, not a model evaluation. Run: python scripts/test_score.py"""
import json
import tempfile
import unittest
from pathlib import Path
from score import MATERIAL, evaluate, read_jsonl, check_prediction

class ScoreTests(unittest.TestCase):
    def setUp(self):
        self.refs = {str(i): {'claim_id':str(i),'draft_material_overstatement':label,'draft_evidence_status':'Mixed',
                             'review_status':'unreviewed_compiler_draft','reviewed_reference_assessment':None,
                             'independent_readiness':'blocked','company_group':str(i)} for i,label in enumerate(MATERIAL)}
        self.preds = {str(i): {'claim_id':str(i),'material_overstatement':label,'evidence_status':'Mixed',
                              'probabilities':{k:float(k==label) for k in MATERIAL}} for i,label in enumerate(MATERIAL)}
    def test_identity(self):
        m=evaluate(self.preds,self.refs,mode='retrospective',allow_draft=True)
        self.assertEqual(m['material_accuracy'],1.0)
        self.assertEqual(m['multiclass_brier_sum_mean'],0.0)
    def test_false_accusation(self):
        self.preds['1']['material_overstatement']='Present'; self.preds['1']['probabilities']=None
        m=evaluate(self.preds,self.refs,mode='retrospective',allow_draft=True)
        self.assertEqual(m['false_accusation_rate_on_absent'],1.0)
        self.assertAlmostEqual(m['material_accuracy'],2/3)
    def test_unresolved_certainty(self):
        self.preds['2']['material_overstatement']='Absent'; self.preds['2']['probabilities']=None
        m=evaluate(self.preds,self.refs,mode='retrospective',allow_draft=True)
        self.assertEqual(m['unjustified_determinate_rate_on_unresolved'],1.0)
    def test_no_draft_by_default(self):
        with self.assertRaises(ValueError):evaluate(self.preds,self.refs,mode='retrospective')
    def test_independent_blocked(self):
        with self.assertRaises(ValueError):evaluate(self.preds,self.refs,mode='independent')
    def test_partial_rejected(self):
        del self.preds['0']
        with self.assertRaises(ValueError):evaluate(self.preds,self.refs,mode='retrospective',allow_draft=True)
    def test_bad_probabilities(self):
        self.preds['0']['probabilities']['Absent']=0.5
        with self.assertRaises(ValueError):check_prediction(self.preds['0'])
    def test_null_template_rejected(self):
        with self.assertRaises(ValueError):check_prediction({'claim_id':'a','material_overstatement':None,'evidence_status':None})
    def test_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'p.jsonl';p.write_text('{"claim_id":"a"}\n{"claim_id":"a"}\n')
            with self.assertRaises(ValueError):read_jsonl(p)
    def test_reviewed_mode_must_match(self):
        self.refs['0']['review_status']='adjudicated'
        self.refs['0']['reviewed_reference_assessment']={'mode':'independent','material_overstatement':'Present','evidence_status':'Mixed'}
        with self.assertRaises(ValueError):evaluate(self.preds,self.refs,mode='retrospective',allow_draft=True)
if __name__=='__main__':unittest.main(verbosity=2)
