#!/usr/bin/env python3
"""Score ASA JSONL predictions. Python 3.10+; standard library only.

The default is conservative: unreviewed drafts cannot be scored without
--allow-draft, and the shipped pack cannot support independent evaluation.
"""
from __future__ import annotations
import argparse
import json
import math
import sys
from collections import Counter
from pathlib import Path
from typing import Any

MATERIAL = ('Present', 'Absent', 'Undetermined')
EVIDENCE = ('Supported', 'Contradicted', 'Mixed', 'Insufficient', 'Not yet resolvable')


def read_jsonl(path: Path) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    with path.open(encoding='utf-8-sig') as handle:
        for number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f'{path}:{number}: invalid JSON: {exc.msg}') from exc
            if not isinstance(item, dict) or not isinstance(item.get('claim_id'), str):
                raise ValueError(f'{path}:{number}: an object with a string claim_id is required')
            ident = item['claim_id']
            if ident in result:
                raise ValueError(f'{path}:{number}: duplicate claim_id {ident}')
            result[ident] = item
    if not result:
        raise ValueError(f'{path}: no records')
    return result


def check_prediction(item: dict[str, Any]) -> None:
    ident = item['claim_id']
    if item.get('material_overstatement') not in MATERIAL:
        raise ValueError(f'{ident}: material_overstatement must be one of {MATERIAL}')
    if item.get('evidence_status') not in EVIDENCE:
        raise ValueError(f'{ident}: evidence_status must be one of {EVIDENCE}')
    if item.get('explanation') is not None and not isinstance(item['explanation'], str):
        raise ValueError(f'{ident}: explanation must be a string or null')
    if 'evidence_ids' in item and (not isinstance(item['evidence_ids'], list) or
            not all(isinstance(x, str) for x in item['evidence_ids'])):
        raise ValueError(f'{ident}: evidence_ids must be a list of strings')
    probabilities = item.get('probabilities')
    if probabilities is not None:
        if not isinstance(probabilities, dict) or set(probabilities) != set(MATERIAL):
            raise ValueError(f'{ident}: probabilities must contain exactly {MATERIAL}')
        for value in probabilities.values():
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f'{ident}: probabilities must be finite numbers from 0 to 1')
        if not math.isclose(sum(probabilities.values()), 1.0, abs_tol=1e-6):
            raise ValueError(f'{ident}: probabilities must sum to 1')
        if probabilities[item['material_overstatement']] < max(probabilities.values()) - 1e-9:
            raise ValueError(f'{ident}: predicted class must maximize its stated probability')


def evaluate(predictions: dict[str, dict[str, Any]], references: dict[str, dict[str, Any]],
             *, mode: str, allow_draft: bool = False, allow_partial: bool = False) -> dict[str, Any]:
    for item in predictions.values():
        check_prediction(item)
    unknown = set(predictions) - set(references)
    if unknown:
        raise ValueError(f'Unknown claim IDs: {sorted(unknown)}')
    missing = set(references) - set(predictions)
    if missing and not allow_partial:
        raise ValueError(f'Missing {len(missing)} predictions. Fill every row, or explicitly use --allow-partial.')
    if mode == 'independent':
        if allow_draft:
            raise ValueError('--allow-draft is not allowed for independent evaluation')
        blocked = [k for k in predictions if references[k].get('independent_readiness') != 'ready']
        if blocked:
            raise ValueError('Independent evaluation blocked: original context, cutoff, evidence and reviewed references must be completed first.')

    selected: dict[str, tuple[str, str]] = {}
    draft_count = 0
    for ident in predictions:
        ref = references[ident]
        reviewed = ref.get('reviewed_reference_assessment')
        if isinstance(reviewed, dict) and ref.get('review_status') == 'adjudicated':
            if reviewed.get('mode') != mode:
                raise ValueError(f'{ident}: reviewed reference mode does not match {mode}')
            label, status = reviewed.get('material_overstatement'), reviewed.get('evidence_status')
        elif allow_draft and mode == 'retrospective':
            label, status = ref.get('draft_material_overstatement'), ref.get('draft_evidence_status')
            draft_count += 1
        else:
            raise ValueError('No adjudicated reference is available. For a provisional retrospective smoke test only, pass --allow-draft.')
        if label not in MATERIAL or status not in EVIDENCE:
            raise ValueError(f'{ident}: malformed reference labels')
        selected[ident] = (label, status)

    n = len(selected)
    confusion = {a: {b: 0 for b in MATERIAL} for a in MATERIAL}
    correct = evidence_correct = certain = certain_correct = 0
    brier: list[float] = []
    grouped: dict[str, list[int]] = {}
    for ident, (truth, evidence_truth) in selected.items():
        pred = predictions[ident]
        guess = pred['material_overstatement']
        confusion[truth][guess] += 1
        hit = int(truth == guess)
        correct += hit
        evidence_correct += int(evidence_truth == pred['evidence_status'])
        if guess != 'Undetermined':
            certain += 1
            certain_correct += hit
        grouped.setdefault(references[ident].get('company_group', ident), []).append(hit)
        if pred.get('probabilities') is not None:
            brier.append(sum((pred['probabilities'][k] - int(k == truth)) ** 2 for k in MATERIAL))

    def divide(x: float, y: float) -> float | None:
        return x / y if y else None
    per_class = {}
    for label in MATERIAL:
        tp = confusion[label][label]
        fp = sum(confusion[other][label] for other in MATERIAL if other != label)
        fn = sum(confusion[label][other] for other in MATERIAL if other != label)
        per_class[label] = {'support': sum(confusion[label].values()), 'precision': divide(tp, tp + fp),
                            'recall': divide(tp, tp + fn), 'f1': divide(2 * tp, 2 * tp + fp + fn)}
    supported_f1 = [v['f1'] or 0.0 for v in per_class.values() if v['support']]
    absent_n = sum(confusion['Absent'].values())
    unresolved_n = sum(confusion['Undetermined'].values())
    return {
        'mode': mode,
        'status': 'PROVISIONAL_DRAFT_COMPARISON_NOT_BENCHMARK_RESULT' if draft_count else 'ADJUDICATED_REFERENCE_COMPARISON',
        'warning': 'Retrospective mode can use answer-bearing summaries; it does not measure independent detection. Explanation and citation correctness require separate review.',
        'reference_count': len(references), 'prediction_count': n, 'prediction_coverage': n / len(references),
        'draft_reference_count': draft_count, 'missing_prediction_ids': sorted(missing),
        'material_accuracy': correct / n, 'evidence_status_accuracy': evidence_correct / n,
        'material_macro_f1_supported_classes': sum(supported_f1) / len(supported_f1),
        'false_accusation_rate_on_absent': divide(confusion['Absent']['Present'], absent_n),
        'unjustified_determinate_rate_on_unresolved': divide(confusion['Undetermined']['Present'] + confusion['Undetermined']['Absent'], unresolved_n),
        'determinate_prediction_rate': certain / n, 'accuracy_among_determinate_predictions': divide(certain_correct, certain),
        'company_macro_accuracy': sum(sum(v) / len(v) for v in grouped.values()) / len(grouped),
        'company_count': len(grouped),
        'multiclass_brier_sum_mean': divide(sum(brier), len(brier)),
        'probability_prediction_count': len(brier),
        'brier_definition': 'Mean sum of squared errors across the three material classes; range 0 to 2. Not divided by class count.',
        'confusion_matrix_rows_reference_columns_prediction': confusion, 'per_class': per_class,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--predictions', required=True, type=Path)
    parser.add_argument('--references', type=Path, default=Path(__file__).resolve().parents[1] / 'evaluator/reference_drafts.jsonl')
    parser.add_argument('--mode', choices=['retrospective', 'independent'], required=True)
    parser.add_argument('--allow-draft', action='store_true')
    parser.add_argument('--allow-partial', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        metrics = evaluate(read_jsonl(args.predictions), read_jsonl(args.references), mode=args.mode,
                           allow_draft=args.allow_draft, allow_partial=args.allow_partial)
        text = json.dumps(metrics, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
        if args.output:
            args.output.write_text(text, encoding='utf-8')
        print(text, end='')
        return 0
    except (ValueError, OSError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
